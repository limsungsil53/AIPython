citys=["Seoul", "New York", "Shanghai", "Paries"]
new_list=[city for city in citys if city[0]=='S']
print(new_list)