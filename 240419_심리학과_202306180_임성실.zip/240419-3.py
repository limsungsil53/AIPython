#join
names=["Python", "java", "ruby"]
new='->'.join(names)
print(new)